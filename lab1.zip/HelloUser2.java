//----------------------------------------------------
//William Propp
//wpropp
//12M
//lab1
//HelloUser.java
// Prints greeting to stdout, then prints out some environment information.
//----------------------------------------------------
class HelloUser2{
   public static void main( String[] args ){
      String userName = System.getProperty("user.name");
      long time = System.currentTimeMillis();
      
      System.out.println("Hello "+userName+"!");
      for(int i = 5 ; i > 0 ; i -= 1){
         System.out.println(i+"...");
      }
      System.out.println("Goodbye "+userName+".");
   }
}
