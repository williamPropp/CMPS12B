//----------------------------------------------------
//William Propp
//wpropp
//12B
//assignment1
//list_funcs.c
//Defines several functions for a rideshare_like program utilizing linked lists
//----------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "list.h"

/* allocates space for the linked list node and initialize the fields with the values passed by the caller */
rider_st *
create_new_rider(int id, char *first_name, char *last_name, double ave_rating, double distance)
{
   int id;
   char *first_name;
   char *last_name;
   double ave_rating;
   double distance;
   rider_st *next;
   rider_st *new_rider_node;
   new_rider_node = (rider_st *) malloc (sizeof (rider_st));
   new_rider_node->ID = id;
   new_rider_node->first_name = first_name;
   new_rider_node->last_name = last_name;
   new_rider_node->ave_rating = ave_rating;
   new_rider_node->distance = distance;
   new_rider_node->next = NULL;

   return new_rider_node;  
}

/* inserts the given node to the front of the list */
void front_insert(rider_st **list_head, rider_st *to_be_inserted){
   to_be_inserted->next = *list_head;
   list_head = to_be_inserted;
}

/* inserts the given node to the end of the list */
void end_insert (rider_st **ptr_to_list_head, rider_st *to_be_inserted){
   while(temp->next != NULL){
      *ptr_to_list_head = ptr_to_list_head->next;
   }
   *to_be_inserted = temp->next;
}

/* inserts the given node into the list based on the distance field ordering, least to greatest */
void ordered_insert (rider_st **ptr_to_list_head, rider_st *to_be_inserted){

}

/* removes all of the nodes in the list and deallocates the space */
void empty(rider_st *list_head){

}

/* removes the given node from the list and deallocates the space */
void delete(rider_st **ptr_to_list_head, rider_st *to_be_deleted){
   
}

/* returns the node that has the next greater distance value than the min_distance value passed */
rider_st find_next_distance_rider( rider_st *list_head, double min_distance){
   
}
