//----------------------------------------------------
//William Propp
//wpropp
//12B
//assignment1
//README.txt
//list of files being submitted
//----------------------------------------------------
Files being submitted:

list.h

list_funcs.c

README.txt
